# Travel App - Aplicación de Gestión de Viajes

Una aplicación web profesional, completa y escalable para crear, planificar, administrar y registrar viajes, construida con tecnologías modernas y mejores prácticas de desarrollo.

## 🌟 Características Principales

### ✅ Autenticación y Usuarios
- Registro e inicio de sesión seguro
- Autenticación con Google OAuth
- JWT con tokens de refresco
- Perfil de usuario con avatar
- Recuperación de contraseña

### 🗺️ Gestión de Viajes Completa
- Crear y gestionar múltiples viajes
- Información detallada: origen, destino, fechas, presupuesto
- Estados del viaje: Planeado, En curso, Finalizado, Cancelado
- Notas y descripciones personalizadas

### 🚗 Rutas y Transporte
- Múltiples rutas por viaje
- Tipos de transporte: Avión, Tren, Auto, Bus, Barco
- Información detallada por ruta
- Códigos de reserva y booking
- Visualización en mapas

### 💰 Presupuesto y Gastos
- Presupuesto total y por categorías
- Registro detallado de gastos
- Categorías: Transporte, Alojamiento, Alimentación, Actividades, Otros
- Dashboard con gráficos y estadísticas
- Control de presupuesto vs gastos reales

### 📅 Calendario Integrado
- Vista tipo agenda/timeline
- Eventos: Vuelos, Check-in/out, Actividades, Recordatorios
- Gestión de recordatorios
- Sincronización con fechas del viaje

### 📄 Gestión de Documentos
- Subida de archivos segura
- Tipos de documentos: Tickets, Reservas, Pasaportes, Seguros
- Almacenamiento en Cloudinary (configurable)
- Organización por viaje

### 🎯 Funcionalidades Avanzadas
- Mapas interactivos con Mapbox
- Dashboard con gráficos Recharts
- Diseño responsive y moderno
- Modo oscuro
- Animaciones suaves
- Filtros avanzados

## 🛠️ Stack Tecnológico

### Backend
- **Node.js** + **NestJS** - Framework backend moderno
- **TypeScript** - Tipado estático
- **PostgreSQL** - Base de datos relacional
- **Prisma** - ORM de nueva generación
- **JWT** - Autenticación segura
- **Swagger** - Documentación API automática
- **Cloudinary** - Almacenamiento de archivos

### Frontend
- **Next.js 14** - Framework React full-stack
- **TypeScript** - Tipado estático
- **Tailwind CSS** - Framework de estilos
- **Shadcn/UI** - Componentes UI modernos
- **React Hook Form** - Gestión de formularios
- **Zod** - Validación de esquemas
- **Recharts** - Gráficos y visualizaciones
- **Mapbox** - Mapas interactivos

### Infraestructura
- **Docker** - Contenerización (opcional)
- **Vercel** - Despliegue frontend
- **Railway** / **AWS** - Despliegue backend
- **PostgreSQL** - Base de datos en cloud

## 📁 Estructura del Proyecto

```
travel-app/
├── backend/                 # API Backend (NestJS)
│   ├── src/
│   │   ├── auth/           # Módulo de autenticación
│   │   ├── trips/          # Módulo de viajes
│   │   ├── routes/         # Módulo de rutas
│   │   ├── expenses/       # Módulo de gastos
│   │   ├── events/         # Módulo de eventos
│   │   ├── documents/      # Módulo de documentos
│   │   ├── users/          # Módulo de usuarios
│   │   ├── prisma/         # Configuración Prisma
│   │   └── main.ts         # Punto de entrada
│   ├── prisma/
│   │   └── schema.prisma   # Esquema de base de datos
│   └── package.json
├── frontend/               # Aplicación Frontend (Next.js)
│   ├── src/
│   │   ├── app/           # App Router (Next.js 14)
│   │   ├── components/    # Componentes React
│   │   ├── services/      # Servicios API
│   │   ├── types/         # Tipos TypeScript
│   │   └── lib/           # Utilidades
│   └── package.json
└── README.md
```

## 🚀 Instalación y Configuración

### Requisitos Previos
- Node.js 18+ 
- PostgreSQL 14+
- npm o yarn

### Backend Setup

1. **Instalar dependencias:**
```bash
cd backend
npm install
```

2. **Configurar variables de entorno:**
```bash
cp .env.example .env
```

Editar `.env` con tus configuraciones:
```env
DATABASE_URL="postgresql://username:password@localhost:5432/travel_app"
JWT_SECRET="your-super-secret-jwt-key"
JWT_EXPIRATION="7d"
GOOGLE_CLIENT_ID="your-google-client-id"
GOOGLE_CLIENT_SECRET="your-google-client-secret"
CLOUDINARY_CLOUD_NAME="your-cloudinary-name"
CLOUDINARY_API_KEY="your-cloudinary-api-key"
CLOUDINARY_API_SECRET="your-cloudinary-api-secret"
MAPBOX_ACCESS_TOKEN="your-mapbox-access-token"
```

3. **Configurar base de datos:**
```bash
npx prisma generate
npx prisma migrate dev
npx prisma db seed
```

4. **Iniciar servidor de desarrollo:**
```bash
npm run start:dev
```

La API estará disponible en: `http://localhost:3001`

Documentación Swagger: `http://localhost:3001/api/docs`

### Frontend Setup

1. **Instalar dependencias:**
```bash
cd frontend
npm install
```

2. **Configurar variables de entorno:**
Crear archivo `.env.local`:
```env
NEXT_PUBLIC_API_URL=http://localhost:3001
```

3. **Iniciar servidor de desarrollo:**
```bash
npm run dev
```

La aplicación estará disponible en: `http://localhost:3000`

## 📡 API Endpoints

### Autenticación
- `POST /api/auth/register` - Registro de usuarios
- `POST /api/auth/login` - Inicio de sesión
- `POST /api/auth/refresh` - Refrescar token
- `POST /api/auth/logout` - Cerrar sesión
- `GET /api/auth/google` - Google OAuth

### Viajes
- `GET /api/trips` - Obtener todos los viajes del usuario
- `GET /api/trips/:id` - Obtener viaje específico
- `POST /api/trips` - Crear nuevo viaje
- `PUT /api/trips/:id` - Actualizar viaje
- `DELETE /api/trips/:id` - Eliminar viaje
- `GET /api/trips/:id/stats` - Estadísticas del viaje

### Rutas
- `GET /api/routes/trip/:tripId` - Rutas de un viaje
- `POST /api/routes` - Crear ruta
- `PUT /api/routes/:id` - Actualizar ruta
- `DELETE /api/routes/:id` - Eliminar ruta

### Gastos
- `GET /api/expenses/trip/:tripId` - Gastos de un viaje
- `POST /api/expenses` - Crear gasto
- `PUT /api/expenses/:id` - Actualizar gasto
- `DELETE /api/expenses/:id` - Eliminar gasto

### Eventos
- `GET /api/events/trip/:tripId` - Eventos de un viaje
- `POST /api/events` - Crear evento
- `PUT /api/events/:id` - Actualizar evento
- `DELETE /api/events/:id` - Eliminar evento

### Documentos
- `GET /api/documents/trip/:tripId` - Documentos de un viaje
- `GET /api/documents/user` - Documentos del usuario
- `POST /api/documents/upload` - Subir documento
- `PUT /api/documents/:id` - Actualizar documento
- `DELETE /api/documents/:id` - Eliminar documento

## 🎨 Características de UI/UX

### Diseño
- Interfaz moderna y limpia
- Diseño responsive (Desktop, Tablet, Móvil)
- Modo oscuro integrado
- Animaciones suaves con CSS y JavaScript
- Componentes reutilizables con Shadcn/UI

### Navegación
- Navegación intuitiva y clara
- Breadcrumbs para contexto
- Menú de usuario desplegable
- Filtros y búsqueda avanzada

### Formularios
- Validación en tiempo real
- Mensajes de error claros
- Indicadores de carga
- Autocompletado inteligente

## 🔒 Seguridad

### Backend
- Hash de contraseñas con bcrypt
- JWT seguro con tokens de refresco
- Validación de entrada (DTOs)
- Protección de rutas con Guards
- Manejo centralizado de errores
- CORS configurado
- Variables de entorno seguras

### Frontend
- Autenticación basada en tokens
- Protección de rutas privadas
- Validación de formularios
- Manejo seguro de archivos
- HTTPS en producción

## 🚀 Despliegue

### Backend (Railway)
1. Conectar repositorio a Railway
2. Configurar variables de entorno
3. Desplegar automáticamente

### Frontend (Vercel)
1. Conectar repositorio a Vercel
2. Configurar variables de entorno
3. Desplegar automáticamente

### Base de datos (Neon/Supabase)
- Crear base de datos PostgreSQL
- Configurar conexión segura
- Realizar migraciones

## 🧪 Testing (Próximamente)

### Backend
- Unit tests con Jest
- Integration tests
- E2E tests

### Frontend
- Component tests con React Testing Library
- E2E tests con Cypress

## 📈 Monitoreo y Logs

- Logs estructurados con Winston
- Monitoreo de errores con Sentry
- Analytics con Google Analytics
- Performance monitoring

## 🤝 Contribución

1. Fork el proyecto
2. Crear rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abrir Pull Request

## 📄 Licencia

Este proyecto está bajo la Licencia MIT. Ver archivo `LICENSE` para más detalles.

## 👥 Autores

- Tu Nombre - [@tu_usuario](https://github.com/tu_usuario)

## 🙏 Agradecimientos

- NestJS Team por el framework backend
- Vercel por Next.js
- Prisma Team por el ORM
- Shadcn por los componentes UI
- Tailwind CSS Team por el framework de estilos

---

## 📞 Soporte

Si tienes alguna pregunta o problema, por favor:
1. Revisa la documentación
2. Busca en issues existentes
3. Crea un nuevo issue con detalles

**¡Gracias por usar Travel App! 🎉**