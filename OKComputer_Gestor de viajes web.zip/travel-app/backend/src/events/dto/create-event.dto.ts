import { IsString, IsDateString, IsOptional, IsEnum } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { EventType } from '@prisma/client';

export class CreateEventDto {
  @ApiProperty({ example: 'trip-id-123' })
  @IsString()
  tripId: string;

  @ApiProperty({ example: 'Flight to Paris' })
  @IsString()
  title: string;

  @ApiProperty({ example: 'Boarding at gate A12', required: false })
  @IsString()
  @IsOptional()
  description?: string;

  @ApiProperty({ example: '2024-06-15T14:30:00Z' })
  @IsDateString()
  startDate: Date;

  @ApiProperty({ example: '2024-06-15T16:00:00Z', required: false })
  @IsDateString()
  @IsOptional()
  endDate?: Date;

  @ApiProperty({ example: 'Charles de Gaulle Airport', required: false })
  @IsString()
  @IsOptional()
  location?: string;

  @ApiProperty({ enum: EventType, example: EventType.FLIGHT })
  @IsEnum(EventType)
  type: EventType;
}