import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateEventDto } from './dto/create-event.dto';
import { UpdateEventDto } from './dto/update-event.dto';

@Injectable()
export class EventsService {
  constructor(private prisma: PrismaService) {}

  async create(createEventDto: CreateEventDto, userId: string) {
    // Verify trip ownership
    const trip = await this.prisma.trip.findFirst({
      where: {
        id: createEventDto.tripId,
        userId,
      },
    });

    if (!trip) {
      throw new ForbiddenException('Access denied');
    }

    return this.prisma.event.create({
      data: createEventDto,
    });
  }

  async findAllByTrip(
    tripId: string,
    userId: string,
    startDate?: string,
    endDate?: string,
  ) {
    // Verify trip ownership
    const trip = await this.prisma.trip.findFirst({
      where: {
        id: tripId,
        userId,
      },
    });

    if (!trip) {
      throw new ForbiddenException('Access denied');
    }

    const where: any = { tripId };

    if (startDate || endDate) {
      where.startDate = {};
      if (startDate) {
        where.startDate.gte = new Date(startDate);
      }
      if (endDate) {
        where.startDate.lte = new Date(endDate);
      }
    }

    return this.prisma.event.findMany({
      where,
      orderBy: { startDate: 'asc' },
    });
  }

  async findOne(id: string, userId: string) {
    const event = await this.prisma.event.findFirst({
      where: { id },
      include: {
        trip: true,
      },
    });

    if (!event || event.trip.userId !== userId) {
      throw new NotFoundException('Event not found');
    }

    return event;
  }

  async update(id: string, updateEventDto: UpdateEventDto, userId: string) {
    const event = await this.findOne(id, userId);

    return this.prisma.event.update({
      where: { id },
      data: updateEventDto,
    });
  }

  async remove(id: string, userId: string) {
    const event = await this.findOne(id, userId);

    await this.prisma.event.delete({
      where: { id },
    });

    return { message: 'Event deleted successfully' };
  }
}