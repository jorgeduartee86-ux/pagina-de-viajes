import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateExpenseDto } from './dto/create-expense.dto';
import { UpdateExpenseDto } from './dto/update-expense.dto';

@Injectable()
export class ExpensesService {
  constructor(private prisma: PrismaService) {}

  async create(createExpenseDto: CreateExpenseDto, userId: string) {
    // Verify trip ownership
    const trip = await this.prisma.trip.findFirst({
      where: {
        id: createExpenseDto.tripId,
        userId,
      },
    });

    if (!trip) {
      throw new ForbiddenException('Access denied');
    }

    return this.prisma.expense.create({
      data: createExpenseDto,
    });
  }

  async findAllByTrip(
    tripId: string,
    userId: string,
    category?: string,
    startDate?: string,
    endDate?: string,
  ) {
    // Verify trip ownership
    const trip = await this.prisma.trip.findFirst({
      where: {
        id: tripId,
        userId,
      },
    });

    if (!trip) {
      throw new ForbiddenException('Access denied');
    }

    const where: any = { tripId };

    if (category) {
      where.category = category;
    }

    if (startDate || endDate) {
      where.date = {};
      if (startDate) {
        where.date.gte = new Date(startDate);
      }
      if (endDate) {
        where.date.lte = new Date(endDate);
      }
    }

    return this.prisma.expense.findMany({
      where,
      orderBy: { date: 'desc' },
    });
  }

  async findOne(id: string, userId: string) {
    const expense = await this.prisma.expense.findFirst({
      where: { id },
      include: {
        trip: true,
      },
    });

    if (!expense || expense.trip.userId !== userId) {
      throw new NotFoundException('Expense not found');
    }

    return expense;
  }

  async update(id: string, updateExpenseDto: UpdateExpenseDto, userId: string) {
    const expense = await this.findOne(id, userId);

    return this.prisma.expense.update({
      where: { id },
      data: updateExpenseDto,
    });
  }

  async remove(id: string, userId: string) {
    const expense = await this.findOne(id, userId);

    await this.prisma.expense.delete({
      where: { id },
    });

    return { message: 'Expense deleted successfully' };
  }
}