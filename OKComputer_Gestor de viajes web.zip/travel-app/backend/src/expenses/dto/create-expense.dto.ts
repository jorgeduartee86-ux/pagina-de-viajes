import { IsString, IsDateString, IsNumber, IsOptional, IsEnum, Min } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { ExpenseCategory } from '@prisma/client';

export class CreateExpenseDto {
  @ApiProperty({ example: 'trip-id-123' })
  @IsString()
  tripId: string;

  @ApiProperty({ enum: ExpenseCategory, example: ExpenseCategory.TRANSPORT })
  @IsEnum(ExpenseCategory)
  category: ExpenseCategory;

  @ApiProperty({ example: 150.75 })
  @IsNumber()
  @Min(0)
  amount: number;

  @ApiProperty({ example: 'USD', default: 'USD' })
  @IsString()
  @IsOptional()
  currency?: string = 'USD';

  @ApiProperty({ example: '2024-06-15' })
  @IsDateString()
  date: Date;

  @ApiProperty({ example: 'Paris, France', required: false })
  @IsString()
  @IsOptional()
  location?: string;

  @ApiProperty({ example: 'Taxi from airport to hotel', required: false })
  @IsString()
  @IsOptional()
  note?: string;
}