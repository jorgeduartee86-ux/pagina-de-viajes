import { IsString, IsDateString, IsNumber, IsOptional, IsEnum, Min } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { TripStatus } from '@prisma/client';

export class CreateTripDto {
  @ApiProperty({ example: 'Summer Vacation in Europe' })
  @IsString()
  title: string;

  @ApiProperty({ example: 'New York, USA' })
  @IsString()
  origin: string;

  @ApiProperty({ example: '2024-06-15' })
  @IsDateString()
  startDate: Date;

  @ApiProperty({ example: '2024-06-30' })
  @IsDateString()
  endDate: Date;

  @ApiProperty({ example: 5000 })
  @IsNumber()
  @Min(0)
  budget: number;

  @ApiProperty({ example: 'USD', default: 'USD' })
  @IsString()
  @IsOptional()
  currency?: string = 'USD';

  @ApiProperty({ enum: TripStatus, default: TripStatus.PLANNED, required: false })
  @IsEnum(TripStatus)
  @IsOptional()
  status?: TripStatus = TripStatus.PLANNED;

  @ApiProperty({ example: 'Trip notes and details', required: false })
  @IsString()
  @IsOptional()
  notes?: string;
}