import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateTripDto } from './dto/create-trip.dto';
import { UpdateTripDto } from './dto/update-trip.dto';

@Injectable()
export class TripsService {
  constructor(private prisma: PrismaService) {}

  async create(createTripDto: CreateTripDto, userId: string) {
    return this.prisma.trip.create({
      data: {
        ...createTripDto,
        userId,
      },
      include: {
        routes: true,
        expenses: true,
        events: true,
        documents: true,
      },
    });
  }

  async findAllByUser(userId: string, status?: string) {
    const where: any = { userId };
    
    if (status) {
      where.status = status;
    }

    return this.prisma.trip.findMany({
      where,
      include: {
        routes: {
          orderBy: { dateTime: 'asc' },
        },
        expenses: true,
        events: {
          orderBy: { startDate: 'asc' },
        },
        documents: true,
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findOne(id: string, userId: string) {
    const trip = await this.prisma.trip.findFirst({
      where: {
        id,
        userId,
      },
      include: {
        routes: {
          orderBy: { dateTime: 'asc' },
        },
        expenses: {
          orderBy: { date: 'desc' },
        },
        events: {
          orderBy: { startDate: 'asc' },
        },
        documents: true,
      },
    });

    if (!trip) {
      throw new NotFoundException('Trip not found');
    }

    return trip;
  }

  async update(id: string, updateTripDto: UpdateTripDto, userId: string) {
    const trip = await this.findOne(id, userId);
    
    return this.prisma.trip.update({
      where: { id },
      data: updateTripDto,
      include: {
        routes: true,
        expenses: true,
        events: true,
        documents: true,
      },
    });
  }

  async remove(id: string, userId: string) {
    const trip = await this.findOne(id, userId);
    
    await this.prisma.trip.delete({
      where: { id },
    });

    return { message: 'Trip deleted successfully' };
  }

  async getTripStats(id: string, userId: string) {
    const trip = await this.findOne(id, userId);
    
    const totalExpenses = await this.prisma.expense.aggregate({
      where: { tripId: id },
      _sum: { amount: true },
    });

    const expensesByCategory = await this.prisma.expense.groupBy({
      by: ['category'],
      where: { tripId: id },
      _sum: { amount: true },
      orderBy: { _sum: { amount: 'desc' } },
    });

    const totalRoutes = await this.prisma.route.count({
      where: { tripId: id },
    });

    const totalEvents = await this.prisma.event.count({
      where: { tripId: id },
    });

    const totalDocuments = await this.prisma.document.count({
      where: { tripId: id },
    });

    return {
      budget: trip.budget,
      totalSpent: totalExpenses._sum.amount || 0,
      remainingBudget: trip.budget - (totalExpenses._sum.amount || 0),
      expensesByCategory: expensesByCategory.map(item => ({
        category: item.category,
        amount: item._sum.amount,
      })),
      totalRoutes,
      totalEvents,
      totalDocuments,
      currency: trip.currency,
    };
  }
}