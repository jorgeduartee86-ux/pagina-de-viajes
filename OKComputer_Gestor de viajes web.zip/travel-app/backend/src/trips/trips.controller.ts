import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  UseGuards,
  Request,
  Query,
} from '@nestjs/common';
import { TripsService } from './trips.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CreateTripDto } from './dto/create-trip.dto';
import { UpdateTripDto } from './dto/update-trip.dto';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';

@ApiTags('trips')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('trips')
export class TripsController {
  constructor(private readonly tripsService: TripsService) {}

  @Get()
  @ApiOperation({ summary: 'Get all user trips' })
  @ApiQuery({ name: 'status', required: false, enum: ['PLANNED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED'] })
  async findAll(@Request() req, @Query('status') status?: string) {
    return this.tripsService.findAllByUser(req.user.id, status);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get trip by id' })
  async findOne(@Param('id') id: string, @Request() req) {
    return this.tripsService.findOne(id, req.user.id);
  }

  @Post()
  @ApiOperation({ summary: 'Create new trip' })
  async create(@Body() createTripDto: CreateTripDto, @Request() req) {
    return this.tripsService.create(createTripDto, req.user.id);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update trip' })
  async update(
    @Param('id') id: string,
    @Body() updateTripDto: UpdateTripDto,
    @Request() req,
  ) {
    return this.tripsService.update(id, updateTripDto, req.user.id);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete trip' })
  async remove(@Param('id') id: string, @Request() req) {
    return this.tripsService.remove(id, req.user.id);
  }

  @Get(':id/stats')
  @ApiOperation({ summary: 'Get trip statistics' })
  async getStats(@Param('id') id: string, @Request() req) {
    return this.tripsService.getTripStats(id, req.user.id);
  }
}