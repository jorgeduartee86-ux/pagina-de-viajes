import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { AuthModule } from './auth/auth.module';
import { TripsModule } from './trips/trips.module';
import { RoutesModule } from './routes/routes.module';
import { ExpensesModule } from './expenses/expenses.module';
import { EventsModule } from './events/events.module';
import { DocumentsModule } from './documents/documents.module';
import { UsersModule } from './users/users.module';
import { PrismaModule } from './prisma/prisma.module';
import { JwtModule } from '@nestjs/jwt';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
    }),
    PrismaModule,
    JwtModule.register({
      global: true,
      secret: process.env.JWT_SECRET,
      signOptions: { expiresIn: process.env.JWT_EXPIRATION || '7d' },
    }),
    AuthModule,
    UsersModule,
    TripsModule,
    RoutesModule,
    ExpensesModule,
    EventsModule,
    DocumentsModule,
  ],
})
export class AppModule {}