import { IsString, IsOptional, IsEnum } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { DocumentType } from '@prisma/client';

export class CreateDocumentDto {
  @ApiProperty({ example: 'Flight Ticket.pdf' })
  @IsString()
  name: string;

  @ApiProperty({ enum: DocumentType, example: DocumentType.TICKET })
  @IsEnum(DocumentType)
  type: DocumentType;

  @ApiProperty({ example: 'trip-id-123', required: false })
  @IsString()
  @IsOptional()
  tripId?: string;
}