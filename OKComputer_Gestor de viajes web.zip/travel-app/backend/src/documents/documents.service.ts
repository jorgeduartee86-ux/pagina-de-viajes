import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateDocumentDto } from './dto/create-document.dto';
import { UpdateDocumentDto } from './dto/update-document.dto';

// Simulación de servicio de almacenamiento (en producción usar Cloudinary o S3)
@Injectable()
export class DocumentsService {
  constructor(private prisma: PrismaService) {}

  async upload(file: Express.Multer.File, createDocumentDto: CreateDocumentDto, userId: string) {
    // Verify trip ownership if tripId is provided
    if (createDocumentDto.tripId) {
      const trip = await this.prisma.trip.findFirst({
        where: {
          id: createDocumentDto.tripId,
          userId,
        },
      });

      if (!trip) {
        throw new ForbiddenException('Access denied');
      }
    }

    // In production, upload to Cloudinary or S3
    const fileUrl = await this.uploadToStorage(file);

    return this.prisma.document.create({
      data: {
        name: createDocumentDto.name,
        url: fileUrl,
        type: createDocumentDto.type,
        size: file.size,
        userId,
        tripId: createDocumentDto.tripId,
      },
    });
  }

  async findAllByTrip(tripId: string, userId: string, type?: string) {
    // Verify trip ownership
    const trip = await this.prisma.trip.findFirst({
      where: {
        id: tripId,
        userId,
      },
    });

    if (!trip) {
      throw new ForbiddenException('Access denied');
    }

    const where: any = { tripId };

    if (type) {
      where.type = type;
    }

    return this.prisma.document.findMany({
      where,
      orderBy: { uploadedAt: 'desc' },
    });
  }

  async findAllByUser(userId: string) {
    return this.prisma.document.findMany({
      where: { userId },
      include: {
        trip: true,
      },
      orderBy: { uploadedAt: 'desc' },
    });
  }

  async findOne(id: string, userId: string) {
    const document = await this.prisma.document.findFirst({
      where: { id },
      include: {
        trip: true,
      },
    });

    if (!document || document.userId !== userId) {
      throw new NotFoundException('Document not found');
    }

    return document;
  }

  async update(id: string, updateDocumentDto: UpdateDocumentDto, userId: string) {
    const document = await this.findOne(id, userId);

    return this.prisma.document.update({
      where: { id },
      data: updateDocumentDto,
    });
  }

  async remove(id: string, userId: string) {
    const document = await this.findOne(id, userId);

    // In production, delete from storage
    await this.deleteFromStorage(document.url);

    await this.prisma.document.delete({
      where: { id },
    });

    return { message: 'Document deleted successfully' };
  }

  private async uploadToStorage(file: Express.Multer.File): Promise<string> {
    // Simulación de subida a Cloudinary
    // En producción, implementar con Cloudinary SDK
    return `https://storage.example.com/documents/${Date.now()}-${file.originalname}`;
  }

  private async deleteFromStorage(fileUrl: string): Promise<void> {
    // Simulación de eliminación desde Cloudinary
    // En producción, implementar con Cloudinary SDK
    console.log(`Deleting file: ${fileUrl}`);
  }
}