import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  UseGuards,
  Request,
  UploadedFile,
  UseInterceptors,
  Query,
} from '@nestjs/common';
import { DocumentsService } from './documents.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CreateDocumentDto } from './dto/create-document.dto';
import { UpdateDocumentDto } from './dto/update-document.dto';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';
import { FileInterceptor } from '@nestjs/platform-express';

@ApiTags('documents')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('documents')
export class DocumentsController {
  constructor(private readonly documentsService: DocumentsService) {}

  @Get('trip/:tripId')
  @ApiOperation({ summary: 'Get all documents for a trip' })
  @ApiQuery({ name: 'type', required: false })
  async findAllByTrip(
    @Param('tripId') tripId: string,
    @Request() req,
    @Query('type') type?: string,
  ) {
    return this.documentsService.findAllByTrip(tripId, req.user.id, type);
  }

  @Get('user')
  @ApiOperation({ summary: 'Get all user documents' })
  async findAllByUser(@Request() req) {
    return this.documentsService.findAllByUser(req.user.id);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get document by id' })
  async findOne(@Param('id') id: string, @Request() req) {
    return this.documentsService.findOne(id, req.user.id);
  }

  @Post('upload')
  @ApiOperation({ summary: 'Upload document' })
  @UseInterceptors(FileInterceptor('file'))
  async upload(
    @UploadedFile() file: Express.Multer.File,
    @Body() createDocumentDto: CreateDocumentDto,
    @Request() req,
  ) {
    return this.documentsService.upload(file, createDocumentDto, req.user.id);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update document' })
  async update(
    @Param('id') id: string,
    @Body() updateDocumentDto: UpdateDocumentDto,
    @Request() req,
  ) {
    return this.documentsService.update(id, updateDocumentDto, req.user.id);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete document' })
  async remove(@Param('id') id: string, @Request() req) {
    return this.documentsService.remove(id, req.user.id);
  }
}