import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateRouteDto } from './dto/create-route.dto';
import { UpdateRouteDto } from './dto/update-route.dto';

@Injectable()
export class RoutesService {
  constructor(private prisma: PrismaService) {}

  async create(createRouteDto: CreateRouteDto, userId: string) {
    // Verify trip ownership
    const trip = await this.prisma.trip.findFirst({
      where: {
        id: createRouteDto.tripId,
        userId,
      },
    });

    if (!trip) {
      throw new ForbiddenException('Access denied');
    }

    return this.prisma.route.create({
      data: createRouteDto,
    });
  }

  async findAllByTrip(tripId: string, userId: string) {
    // Verify trip ownership
    const trip = await this.prisma.trip.findFirst({
      where: {
        id: tripId,
        userId,
      },
    });

    if (!trip) {
      throw new ForbiddenException('Access denied');
    }

    return this.prisma.route.findMany({
      where: { tripId },
      orderBy: { dateTime: 'asc' },
    });
  }

  async findOne(id: string, userId: string) {
    const route = await this.prisma.route.findFirst({
      where: { id },
      include: {
        trip: true,
      },
    });

    if (!route || route.trip.userId !== userId) {
      throw new NotFoundException('Route not found');
    }

    return route;
  }

  async update(id: string, updateRouteDto: UpdateRouteDto, userId: string) {
    const route = await this.findOne(id, userId);

    return this.prisma.route.update({
      where: { id },
      data: updateRouteDto,
    });
  }

  async remove(id: string, userId: string) {
    const route = await this.findOne(id, userId);

    await this.prisma.route.delete({
      where: { id },
    });

    return { message: 'Route deleted successfully' };
  }
}