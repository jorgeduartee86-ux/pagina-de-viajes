import { IsString, IsDateString, IsNumber, IsOptional, IsEnum, Min } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { TransportType } from '@prisma/client';

export class CreateRouteDto {
  @ApiProperty({ example: 'trip-id-123' })
  @IsString()
  tripId: string;

  @ApiProperty({ example: 'New York, USA' })
  @IsString()
  origin: string;

  @ApiProperty({ example: 'London, UK' })
  @IsString()
  destination: string;

  @ApiProperty({ enum: TransportType, example: TransportType.FLIGHT })
  @IsEnum(TransportType)
  transportType: TransportType;

  @ApiProperty({ example: '2024-06-15T10:30:00Z' })
  @IsDateString()
  dateTime: Date;

  @ApiProperty({ example: '8h 30m', required: false })
  @IsString()
  @IsOptional()
  duration?: string;

  @ApiProperty({ example: 450.50, required: false })
  @IsNumber()
  @Min(0)
  @IsOptional()
  cost?: number;

  @ApiProperty({ example: 'FL123456', required: false })
  @IsString()
  @IsOptional()
  bookingCode?: string;
}