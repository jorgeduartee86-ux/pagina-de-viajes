import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  UseGuards,
  Request,
  Query,
} from '@nestjs/common';
import { RoutesService } from './routes.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CreateRouteDto } from './dto/create-route.dto';
import { UpdateRouteDto } from './dto/update-route.dto';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';

@ApiTags('routes')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('routes')
export class RoutesController {
  constructor(private readonly routesService: RoutesService) {}

  @Get('trip/:tripId')
  @ApiOperation({ summary: 'Get all routes for a trip' })
  async findAllByTrip(@Param('tripId') tripId: string, @Request() req) {
    return this.routesService.findAllByTrip(tripId, req.user.id);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get route by id' })
  async findOne(@Param('id') id: string, @Request() req) {
    return this.routesService.findOne(id, req.user.id);
  }

  @Post()
  @ApiOperation({ summary: 'Create new route' })
  async create(@Body() createRouteDto: CreateRouteDto, @Request() req) {
    return this.routesService.create(createRouteDto, req.user.id);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update route' })
  async update(
    @Param('id') id: string,
    @Body() updateRouteDto: UpdateRouteDto,
    @Request() req,
  ) {
    return this.routesService.update(id, updateRouteDto, req.user.id);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete route' })
  async remove(@Param('id') id: string, @Request() req) {
    return this.routesService.remove(id, req.user.id);
  }
}